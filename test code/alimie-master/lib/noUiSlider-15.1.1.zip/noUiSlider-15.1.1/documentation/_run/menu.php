<div class="bar-group">
    <a class="bar-link project" href="/nouislider/">noUiSlider</a>
    <a class="bar-link" href="/nouislider/slider-values/">Range and Handles</a>
    <a class="bar-link" href="/nouislider/slider-read-write/">Reading &amp; Setting Values</a>
    <a class="bar-link" href="/nouislider/number-formatting/">Formatting</a>
    <a class="bar-link" href="/nouislider/slider-options/">Options</a>
    <a class="bar-link" href="/nouislider/behaviour-option/">Tapping, Dragging &amp; Fixed Ranges</a>
    <a class="bar-link" href="/nouislider/examples/">Examples</a>
    <a class="bar-link" href="/nouislider/events-callbacks/">Events</a>
    <a class="bar-link" href="/nouislider/pips/">Scale/Pips</a>
    <a class="bar-link" href="/nouislider/more/">Updating, Disabling &amp; Styling</a>
    <a class="bar-link download" href="/nouislider/download/">Download</a>
</div>
